﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace LibraryBookStoreManagementSystem
{
    public partial class Users_Form : Form
    {
        public Users_Form()
        {
            InitializeComponent();
        }

        private void btn_adminlogin_Click(object sender, EventArgs e)
        {
            Admin_Login_Form ob = new Admin_Login_Form();
            ob.Show();
            this.Hide();
        }

        private void btn_managerlogin_Click(object sender, EventArgs e)
        {
            Manager_Login_Form ob = new Manager_Login_Form();
            ob.Show();
            this.Hide();
        }

        private void Users_Form_Load(object sender, EventArgs e)
        {

        }

        private void login_as_label_Click(object sender, EventArgs e)
        {

        }
    }
}
