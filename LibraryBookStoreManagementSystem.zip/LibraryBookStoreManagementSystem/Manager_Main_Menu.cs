﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryBookStoreManagementSystem
{
    public partial class Manager_Main_Menu : Form
    {
        public Manager_Main_Menu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Manager_New_Book_Entry ob = new Manager_New_Book_Entry();
            ob.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Manager_Edit_Book_Info ob = new Manager_Edit_Book_Info();
            ob.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Manager_Book_Search ob = new Manager_Book_Search();
            ob.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Manager_Delete_Book ob = new Manager_Delete_Book();
            ob.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Users_Form ob = new Users_Form();
            ob.Show();
            this.Hide();
        }
    }
}
