﻿namespace LibraryBookStoreManagementSystem
{
    partial class Manager_Login_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_managerlogin = new System.Windows.Forms.Button();
            this.user_pass_panel = new System.Windows.Forms.Panel();
            this.usernameBox2 = new System.Windows.Forms.TextBox();
            this.username_label = new System.Windows.Forms.Label();
            this.btn_manager_ok = new System.Windows.Forms.Button();
            this.password_label = new System.Windows.Forms.Label();
            this.btn_manager_back = new System.Windows.Forms.Button();
            this.passwordBox2 = new System.Windows.Forms.TextBox();
            this.manager_logo = new System.Windows.Forms.PictureBox();
            this.user_pass_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.manager_logo)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_managerlogin
            // 
            this.btn_managerlogin.BackColor = System.Drawing.Color.DarkOrange;
            this.btn_managerlogin.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_managerlogin.Location = new System.Drawing.Point(188, 159);
            this.btn_managerlogin.Name = "btn_managerlogin";
            this.btn_managerlogin.Size = new System.Drawing.Size(75, 23);
            this.btn_managerlogin.TabIndex = 5;
            this.btn_managerlogin.Text = "Manager";
            this.btn_managerlogin.UseVisualStyleBackColor = false;
            // 
            // user_pass_panel
            // 
            this.user_pass_panel.Controls.Add(this.usernameBox2);
            this.user_pass_panel.Controls.Add(this.username_label);
            this.user_pass_panel.Controls.Add(this.btn_manager_ok);
            this.user_pass_panel.Controls.Add(this.password_label);
            this.user_pass_panel.Controls.Add(this.btn_manager_back);
            this.user_pass_panel.Controls.Add(this.passwordBox2);
            this.user_pass_panel.Location = new System.Drawing.Point(122, 206);
            this.user_pass_panel.Name = "user_pass_panel";
            this.user_pass_panel.Size = new System.Drawing.Size(200, 110);
            this.user_pass_panel.TabIndex = 13;
            // 
            // usernameBox2
            // 
            this.usernameBox2.Location = new System.Drawing.Point(89, 10);
            this.usernameBox2.Name = "usernameBox2";
            this.usernameBox2.Size = new System.Drawing.Size(100, 20);
            this.usernameBox2.TabIndex = 6;
            // 
            // username_label
            // 
            this.username_label.AutoSize = true;
            this.username_label.Location = new System.Drawing.Point(3, 13);
            this.username_label.Name = "username_label";
            this.username_label.Size = new System.Drawing.Size(80, 13);
            this.username_label.TabIndex = 4;
            this.username_label.Text = "Manager Name";
            // 
            // btn_manager_ok
            // 
            this.btn_manager_ok.Location = new System.Drawing.Point(105, 77);
            this.btn_manager_ok.Name = "btn_manager_ok";
            this.btn_manager_ok.Size = new System.Drawing.Size(75, 23);
            this.btn_manager_ok.TabIndex = 9;
            this.btn_manager_ok.Text = "OK";
            this.btn_manager_ok.UseVisualStyleBackColor = true;
            this.btn_manager_ok.Click += new System.EventHandler(this.btn_manager_ok_Click);
            // 
            // password_label
            // 
            this.password_label.AutoSize = true;
            this.password_label.Location = new System.Drawing.Point(30, 43);
            this.password_label.Name = "password_label";
            this.password_label.Size = new System.Drawing.Size(53, 13);
            this.password_label.TabIndex = 5;
            this.password_label.Text = "Password";
            // 
            // btn_manager_back
            // 
            this.btn_manager_back.Location = new System.Drawing.Point(22, 77);
            this.btn_manager_back.Name = "btn_manager_back";
            this.btn_manager_back.Size = new System.Drawing.Size(75, 23);
            this.btn_manager_back.TabIndex = 8;
            this.btn_manager_back.Text = "BACK";
            this.btn_manager_back.UseVisualStyleBackColor = true;
            this.btn_manager_back.Click += new System.EventHandler(this.btn_manager_back_Click);
            // 
            // passwordBox2
            // 
            this.passwordBox2.Location = new System.Drawing.Point(89, 40);
            this.passwordBox2.Name = "passwordBox2";
            this.passwordBox2.PasswordChar = '*';
            this.passwordBox2.Size = new System.Drawing.Size(100, 20);
            this.passwordBox2.TabIndex = 7;
            // 
            // manager_logo
            // 
            this.manager_logo.Image = global::LibraryBookStoreManagementSystem.Properties.Resources.manager_logo;
            this.manager_logo.Location = new System.Drawing.Point(161, 50);
            this.manager_logo.Name = "manager_logo";
            this.manager_logo.Size = new System.Drawing.Size(131, 103);
            this.manager_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.manager_logo.TabIndex = 4;
            this.manager_logo.TabStop = false;
            // 
            // Manager_Login_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 365);
            this.Controls.Add(this.user_pass_panel);
            this.Controls.Add(this.btn_managerlogin);
            this.Controls.Add(this.manager_logo);
            this.Name = "Manager_Login_Form";
            this.Text = "Manager_Login_Form";
            this.user_pass_panel.ResumeLayout(false);
            this.user_pass_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.manager_logo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox manager_logo;
        private System.Windows.Forms.Button btn_managerlogin;
        private System.Windows.Forms.Panel user_pass_panel;
        private System.Windows.Forms.TextBox usernameBox2;
        private System.Windows.Forms.Label username_label;
        private System.Windows.Forms.Button btn_manager_ok;
        private System.Windows.Forms.Label password_label;
        private System.Windows.Forms.Button btn_manager_back;
        private System.Windows.Forms.TextBox passwordBox2;
    }
}