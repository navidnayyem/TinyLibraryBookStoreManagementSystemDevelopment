﻿namespace LibraryBookStoreManagementSystem
{
    partial class Admin_Login_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_adminlogin = new System.Windows.Forms.Button();
            this.user_pass_panel = new System.Windows.Forms.Panel();
            this.usernameBox1 = new System.Windows.Forms.TextBox();
            this.username_label = new System.Windows.Forms.Label();
            this.btn_admin_ok = new System.Windows.Forms.Button();
            this.password_label = new System.Windows.Forms.Label();
            this.btn_admin_back = new System.Windows.Forms.Button();
            this.passwordBox1 = new System.Windows.Forms.TextBox();
            this.admin_logo = new System.Windows.Forms.PictureBox();
            this.user_pass_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.admin_logo)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_adminlogin
            // 
            this.btn_adminlogin.BackColor = System.Drawing.Color.DarkOrange;
            this.btn_adminlogin.Location = new System.Drawing.Point(188, 159);
            this.btn_adminlogin.Name = "btn_adminlogin";
            this.btn_adminlogin.Size = new System.Drawing.Size(75, 23);
            this.btn_adminlogin.TabIndex = 4;
            this.btn_adminlogin.Text = "Admin";
            this.btn_adminlogin.UseVisualStyleBackColor = false;
            // 
            // user_pass_panel
            // 
            this.user_pass_panel.Controls.Add(this.usernameBox1);
            this.user_pass_panel.Controls.Add(this.username_label);
            this.user_pass_panel.Controls.Add(this.btn_admin_ok);
            this.user_pass_panel.Controls.Add(this.password_label);
            this.user_pass_panel.Controls.Add(this.btn_admin_back);
            this.user_pass_panel.Controls.Add(this.passwordBox1);
            this.user_pass_panel.Location = new System.Drawing.Point(122, 206);
            this.user_pass_panel.Name = "user_pass_panel";
            this.user_pass_panel.Size = new System.Drawing.Size(200, 110);
            this.user_pass_panel.TabIndex = 12;
            // 
            // usernameBox1
            // 
            this.usernameBox1.Location = new System.Drawing.Point(80, 10);
            this.usernameBox1.Name = "usernameBox1";
            this.usernameBox1.Size = new System.Drawing.Size(100, 20);
            this.usernameBox1.TabIndex = 6;
            // 
            // username_label
            // 
            this.username_label.AutoSize = true;
            this.username_label.Location = new System.Drawing.Point(19, 13);
            this.username_label.Name = "username_label";
            this.username_label.Size = new System.Drawing.Size(55, 13);
            this.username_label.TabIndex = 4;
            this.username_label.Text = "Username";
            // 
            // btn_admin_ok
            // 
            this.btn_admin_ok.Location = new System.Drawing.Point(105, 77);
            this.btn_admin_ok.Name = "btn_admin_ok";
            this.btn_admin_ok.Size = new System.Drawing.Size(75, 23);
            this.btn_admin_ok.TabIndex = 9;
            this.btn_admin_ok.Text = "OK";
            this.btn_admin_ok.UseVisualStyleBackColor = true;
            this.btn_admin_ok.Click += new System.EventHandler(this.btn_admin_ok_Click);
            // 
            // password_label
            // 
            this.password_label.AutoSize = true;
            this.password_label.Location = new System.Drawing.Point(20, 43);
            this.password_label.Name = "password_label";
            this.password_label.Size = new System.Drawing.Size(53, 13);
            this.password_label.TabIndex = 5;
            this.password_label.Text = "Password";
            // 
            // btn_admin_back
            // 
            this.btn_admin_back.Location = new System.Drawing.Point(22, 77);
            this.btn_admin_back.Name = "btn_admin_back";
            this.btn_admin_back.Size = new System.Drawing.Size(75, 23);
            this.btn_admin_back.TabIndex = 8;
            this.btn_admin_back.Text = "BACK";
            this.btn_admin_back.UseVisualStyleBackColor = true;
            this.btn_admin_back.Click += new System.EventHandler(this.btn_admin_back_Click);
            // 
            // passwordBox1
            // 
            this.passwordBox1.Location = new System.Drawing.Point(80, 40);
            this.passwordBox1.Name = "passwordBox1";
            this.passwordBox1.PasswordChar = '*';
            this.passwordBox1.Size = new System.Drawing.Size(100, 20);
            this.passwordBox1.TabIndex = 7;
            // 
            // admin_logo
            // 
            this.admin_logo.Image = global::LibraryBookStoreManagementSystem.Properties.Resources.admin_logo;
            this.admin_logo.Location = new System.Drawing.Point(161, 50);
            this.admin_logo.Name = "admin_logo";
            this.admin_logo.Size = new System.Drawing.Size(131, 103);
            this.admin_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.admin_logo.TabIndex = 3;
            this.admin_logo.TabStop = false;
            // 
            // Admin_Login_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 365);
            this.Controls.Add(this.user_pass_panel);
            this.Controls.Add(this.btn_adminlogin);
            this.Controls.Add(this.admin_logo);
            this.Name = "Admin_Login_Form";
            this.Text = "Admin_Login_Form";
            this.Load += new System.EventHandler(this.Admin_Login_Form_Load);
            this.user_pass_panel.ResumeLayout(false);
            this.user_pass_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.admin_logo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox admin_logo;
        private System.Windows.Forms.Button btn_adminlogin;
        private System.Windows.Forms.Panel user_pass_panel;
        private System.Windows.Forms.TextBox usernameBox1;
        private System.Windows.Forms.Label username_label;
        private System.Windows.Forms.Button btn_admin_ok;
        private System.Windows.Forms.Label password_label;
        private System.Windows.Forms.Button btn_admin_back;
        private System.Windows.Forms.TextBox passwordBox1;
    }
}