﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using Oracle.ManagedDataAccess.Client;
using System.Data.OracleClient;

namespace LibraryBookStoreManagementSystem
{
    public partial class Admin_Manager_Create_Delete_Form : Form
    {
        public Admin_Manager_Create_Delete_Form()
        {
            InitializeComponent();
        }

        private void Admin_Manager_Create_Delete_Form_Load(object sender, EventArgs e)
        {
            connection CN = new connection();
            CN.thisConnection.Open();
            OracleCommand thisCommand = CN.thisConnection.CreateCommand();
            thisCommand.CommandText = "SELECT * FROM manager_login";
            OracleDataReader thisReader = thisCommand.ExecuteReader();
            while (thisReader.Read())
            {
                ListViewItem lsvItem = new ListViewItem();
                lsvItem.Text = thisReader["Username"].ToString();
                lsvItem.SubItems.Add(thisReader["Password"].ToString());
                listView1.Items.Add(lsvItem);
            }
            CN.thisConnection.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Users_Form ob = new Users_Form();
            ob.Show();
            this.Hide();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection sv = new connection();
            sv.thisConnection.Open();

            OracleDataAdapter thisAdapter = new OracleDataAdapter("SELECT * FROM Manager_Login", sv.thisConnection);

            OracleCommandBuilder thisBuilder = new OracleCommandBuilder(thisAdapter);

            DataSet thisDataSet = new DataSet();
            thisAdapter.Fill(thisDataSet, "Manager_Login");

            DataRow thisRow = thisDataSet.Tables["Manager_Login"].NewRow();
            try
            {

                thisRow["Username"] = textBox1.Text;
                thisRow["Password"] = textBox2.Text;

                thisDataSet.Tables["Manager_Login"].Rows.Add(thisRow);


                thisAdapter.Update(thisDataSet, "Manager_Login");
                MessageBox.Show("New Manager Account Created");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            Admin_Manager_Create_Delete_Form ob = new Admin_Manager_Create_Delete_Form();
            ob.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            connection sv = new connection();
            sv.thisConnection.Open();
            OracleCommand thisCommand = sv.thisConnection.CreateCommand();

            thisCommand.CommandText = "Delete from Manager_Login where username = '" + textBox3.Text + "'";
            thisCommand.Connection = sv.thisConnection;
            thisCommand.CommandType = CommandType.Text;

            try
            {
                thisCommand.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Account Not Deleted! Check Manager Username");
            }

            sv.thisConnection.Close();
            Admin_Manager_Create_Delete_Form ob = new Admin_Manager_Create_Delete_Form();
            ob.Show();
            this.Hide();
        }
    }
}
