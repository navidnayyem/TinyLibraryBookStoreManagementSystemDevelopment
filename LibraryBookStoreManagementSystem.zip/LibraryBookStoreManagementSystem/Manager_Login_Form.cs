﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;
namespace LibraryBookStoreManagementSystem
{
    public partial class Manager_Login_Form : Form
    {
        public Manager_Login_Form()
        {
            InitializeComponent();
        }

        private void btn_manager_back_Click(object sender, EventArgs e)
        {
            Users_Form ob = new Users_Form();
            ob.Show();
            this.Hide();
        }

        private void btn_manager_ok_Click(object sender, EventArgs e)
        {
            connection CN = new connection();

            CN.thisConnection.Open();
            OracleCommand thisCommand = new OracleCommand();
            thisCommand.Connection = CN.thisConnection;
            thisCommand.CommandText = "SELECT * FROM manager_login WHERE Username='" + usernameBox2.Text + "' AND Password='" + passwordBox2.Text + "'";
            OracleDataReader thisReader = thisCommand.ExecuteReader();

            if (thisReader.Read())
            //if (Convert.ToBoolean(thisReader.Read()))
            {
                Manager_Main_Menu form = new Manager_Main_Menu();
                form.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Username or Password Incorrect");
            }
            CN.thisConnection.Close();
        }
    }
}
