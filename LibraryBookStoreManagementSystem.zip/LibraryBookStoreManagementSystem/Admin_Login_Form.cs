﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace LibraryBookStoreManagementSystem
{
    public partial class Admin_Login_Form : Form
    {
        public Admin_Login_Form()
        {
            InitializeComponent();
        }

        private void btn_admin_back_Click(object sender, EventArgs e)
        {
            Users_Form ob = new Users_Form();
            ob.Show();
            this.Hide();
        }

        private void btn_admin_ok_Click(object sender, EventArgs e)
        {
            connection CN = new connection();

            CN.thisConnection.Open();
            OracleCommand thisCommand = new OracleCommand();
            thisCommand.Connection = CN.thisConnection;
            thisCommand.CommandText = "SELECT * FROM Login WHERE Username='" + usernameBox1.Text + "' AND Password='" + passwordBox1.Text + "'";
            OracleDataReader thisReader = thisCommand.ExecuteReader();

            if (thisReader.Read())
            //if (Convert.ToBoolean(thisReader.Read()))
            {
                Admin_Manager_Create_Delete_Form form = new Admin_Manager_Create_Delete_Form();
                form.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Username or Password Incorrect");
            }
            CN.thisConnection.Close();         
        }

        private void Admin_Login_Form_Load(object sender, EventArgs e)
        {

        }
    }
}
