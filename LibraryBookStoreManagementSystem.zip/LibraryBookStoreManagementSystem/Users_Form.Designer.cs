﻿namespace LibraryBookStoreManagementSystem
{
    partial class Users_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_adminlogin = new System.Windows.Forms.Button();
            this.btn_managerlogin = new System.Windows.Forms.Button();
            this.login_as_label = new System.Windows.Forms.Label();
            this.manager_logo = new System.Windows.Forms.PictureBox();
            this.admin_logo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.manager_logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.admin_logo)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_adminlogin
            // 
            this.btn_adminlogin.Location = new System.Drawing.Point(95, 160);
            this.btn_adminlogin.Name = "btn_adminlogin";
            this.btn_adminlogin.Size = new System.Drawing.Size(75, 23);
            this.btn_adminlogin.TabIndex = 0;
            this.btn_adminlogin.Text = "Admin";
            this.btn_adminlogin.UseVisualStyleBackColor = true;
            this.btn_adminlogin.Click += new System.EventHandler(this.btn_adminlogin_Click);
            // 
            // btn_managerlogin
            // 
            this.btn_managerlogin.Location = new System.Drawing.Point(256, 160);
            this.btn_managerlogin.Name = "btn_managerlogin";
            this.btn_managerlogin.Size = new System.Drawing.Size(75, 23);
            this.btn_managerlogin.TabIndex = 1;
            this.btn_managerlogin.Text = "Manager";
            this.btn_managerlogin.UseVisualStyleBackColor = true;
            this.btn_managerlogin.Click += new System.EventHandler(this.btn_managerlogin_Click);
            // 
            // login_as_label
            // 
            this.login_as_label.AutoSize = true;
            this.login_as_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login_as_label.Location = new System.Drawing.Point(172, 9);
            this.login_as_label.Name = "login_as_label";
            this.login_as_label.Size = new System.Drawing.Size(101, 24);
            this.login_as_label.TabIndex = 10;
            this.login_as_label.Text = "Login User";
            this.login_as_label.Click += new System.EventHandler(this.login_as_label_Click);
            // 
            // manager_logo
            // 
            this.manager_logo.Image = global::LibraryBookStoreManagementSystem.Properties.Resources.manager_logo;
            this.manager_logo.Location = new System.Drawing.Point(231, 51);
            this.manager_logo.Name = "manager_logo";
            this.manager_logo.Size = new System.Drawing.Size(128, 103);
            this.manager_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.manager_logo.TabIndex = 3;
            this.manager_logo.TabStop = false;
            // 
            // admin_logo
            // 
            this.admin_logo.Image = global::LibraryBookStoreManagementSystem.Properties.Resources.admin_logo;
            this.admin_logo.Location = new System.Drawing.Point(69, 51);
            this.admin_logo.Name = "admin_logo";
            this.admin_logo.Size = new System.Drawing.Size(131, 103);
            this.admin_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.admin_logo.TabIndex = 2;
            this.admin_logo.TabStop = false;
            // 
            // Users_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 211);
            this.Controls.Add(this.login_as_label);
            this.Controls.Add(this.manager_logo);
            this.Controls.Add(this.admin_logo);
            this.Controls.Add(this.btn_managerlogin);
            this.Controls.Add(this.btn_adminlogin);
            this.Name = "Users_Form";
            this.Text = "Library Book Store Management System";
            this.Load += new System.EventHandler(this.Users_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.manager_logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.admin_logo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_adminlogin;
        private System.Windows.Forms.Button btn_managerlogin;
        private System.Windows.Forms.PictureBox admin_logo;
        private System.Windows.Forms.PictureBox manager_logo;
        private System.Windows.Forms.Label login_as_label;
    }
}

