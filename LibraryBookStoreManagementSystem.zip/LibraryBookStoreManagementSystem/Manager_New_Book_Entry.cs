﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace LibraryBookStoreManagementSystem
{
    public partial class Manager_New_Book_Entry : Form
    {
        public Manager_New_Book_Entry()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Manager_Main_Menu ob = new Manager_Main_Menu();
            ob.Show();
            this.Hide();
        }

        private void Manager_New_Book_Entry_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            connection sv = new connection();
            sv.thisConnection.Open();

            OracleDataAdapter thisAdapter = new OracleDataAdapter("SELECT * FROM ManagerBookEntry", sv.thisConnection);

            OracleCommandBuilder thisBuilder = new OracleCommandBuilder(thisAdapter);

            DataSet thisDataSet = new DataSet();
            thisAdapter.Fill(thisDataSet, "ManagerBookEntry");

            DataRow thisRow = thisDataSet.Tables["ManagerBookEntry"].NewRow();
            try
            {
                thisRow["BookName"] = textBox1.Text;
                thisRow["BookPublishYear"] = textBox6.Text;
                thisRow["WriterName"] = textBox2.Text;
                thisRow["QuantityOfBook"] = textBox3.Text;
                thisRow["CatagoryName"] = comboBox2.Text;
                thisRow["EntryDate"] = dateTimePicker1.Text;
                thisRow["AvaliableBook"] = textBox4.Text;
                thisRow["BorrowBook"] = textBox5.Text;

                thisDataSet.Tables["ManagerBookEntry"].Rows.Add(thisRow);
                thisAdapter.Update(thisDataSet, "ManagerBookEntry");
                MessageBox.Show("Book Entry Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            Manager_New_Book_Entry ob = new Manager_New_Book_Entry();
            ob.Show();
            this.Hide();
        }
    }
}
