﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace LibraryBookStoreManagementSystem
{
    public partial class Manager_Delete_Book : Form
    {
        public Manager_Delete_Book()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Manager_Main_Menu ob = new Manager_Main_Menu();
            ob.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection c = new connection();
            c.thisConnection.Open();
            OracleCommand thisCommand = c.thisConnection.CreateCommand();
            thisCommand.CommandText = "SELECT BookName,WriterName,AvaliableBook,CatagoryName FROM ManagerBookEntry where BookName='" + textBox1.Text + "' OR WriterName='" + textBox1.Text + "order by BookName'";
            OracleDataReader thisReader = thisCommand.ExecuteReader();
            if (thisReader.HasRows)
            {
                thisCommand.CommandText = "Delete from ManagerBookEntry where bookname = '" + this.textBox1.Text + "' or writername = '" + this.textBox1.Text + "'";
                thisCommand.Connection = c.thisConnection;
                thisCommand.CommandType = CommandType.Text;

                try
                {
                    thisCommand.ExecuteNonQuery();
                    MessageBox.Show("Book Stock Deleted!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Book Not Found!");
            }
            c.thisConnection.Close();
            Manager_Delete_Book ob = new Manager_Delete_Book();
            ob.Show();
            this.Hide();
        }

        private void Manager_Delete_Book_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add(new KeyValuePair<string, string>("BookName", "0"));
            comboBox1.Items.Add(new KeyValuePair<string, string>("BookWriterName", "1"));
            comboBox1.DisplayMember = "key";
            comboBox1.ValueMember = "value";
        }
    }
}
