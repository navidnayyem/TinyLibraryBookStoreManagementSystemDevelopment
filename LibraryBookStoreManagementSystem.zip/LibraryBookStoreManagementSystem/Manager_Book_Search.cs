﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace LibraryBookStoreManagementSystem
{
    public partial class Manager_Book_Search : Form
    {
        public Manager_Book_Search()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Manager_Main_Menu ob = new Manager_Main_Menu();
            ob.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection c = new connection();
            c.thisConnection.Open();
            OracleCommand thisCommand = c.thisConnection.CreateCommand();
            thisCommand.CommandText = "SELECT BookName,WriterName,AvaliableBook,CatagoryName FROM ManagerBookEntry where BookName='" + textBox1.Text + "' OR WriterName='" + textBox1.Text + "order by BookName'";
            OracleDataReader thisReader = thisCommand.ExecuteReader();
            if (thisReader.HasRows)
            {
                while (thisReader.Read())
                {
                    ListViewItem lsvItem = new ListViewItem();
                    lsvItem.Text = thisReader["BookName"].ToString();
                    lsvItem.SubItems.Add(thisReader["WriterName"].ToString());
                    lsvItem.SubItems.Add(thisReader["AvaliableBook"].ToString());
                    lsvItem.SubItems.Add(thisReader["CatagoryName"].ToString());
                    listView1.Items.Add(lsvItem);
                    MessageBox.Show("Book Found!");
                }
            }
            else
            {
                MessageBox.Show("Book Not Found!");
            }
            c.thisConnection.Close();
        }
        
        private void Manager_Book_Search_Load(object sender, EventArgs e)
        {
            comboBox2.Items.Add(new KeyValuePair<string, string>("BookName", "0"));
            comboBox2.Items.Add(new KeyValuePair<string, string>("BookWriterName", "1"));
            comboBox2.DisplayMember = "key";
            comboBox2.ValueMember = "value";
        }
    }
}