﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace LibraryBookStoreManagementSystem
{
    public partial class Manager_Edit_Book_Info : Form
    {
        public Manager_Edit_Book_Info()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Manager_Main_Menu ob = new Manager_Main_Menu();
            ob.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection c = new connection();
            c.thisConnection.Open();
            OracleCommand thisCommand = c.thisConnection.CreateCommand();
            thisCommand.CommandText = "SELECT BookName,BookPublishYear,WriterName,CatagoryName,EntryDate,AvaliableBook FROM ManagerBookEntry where BookName='" + textBox5.Text + "' OR WriterName='" + textBox5.Text + "order by BookName'";
            OracleDataReader thisReader = thisCommand.ExecuteReader();
            if (thisReader.HasRows)
            {
                while (thisReader.Read())
                {
                    ListViewItem lsvItem = new ListViewItem();
                    lsvItem.Text = thisReader["BookName"].ToString();
                    lsvItem.SubItems.Add(thisReader["BookPublishYear"].ToString());
                    lsvItem.SubItems.Add(thisReader["WriterName"].ToString());
                    lsvItem.SubItems.Add(thisReader["CatagoryName"].ToString());
                    lsvItem.SubItems.Add(thisReader["EntryDate"].ToString());
                    lsvItem.SubItems.Add(thisReader["AvaliableBook"].ToString());
                    listView1.Items.Add(lsvItem);
                    MessageBox.Show("Book Found!");
                }
            }
            else
            {
                MessageBox.Show("Book Not Found!");
            }
            listView1.Items[0].Focused = true;
            listView1.Items[0].Selected = true;
            c.thisConnection.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            connection sv = new connection();
            sv.thisConnection.Open();
            OracleCommand thisCommand = sv.thisConnection.CreateCommand();
            textBox7.Text = Convert.ToString(Convert.ToInt32(textBox3.Text) + Convert.ToInt32(textBox4.Text)).ToString();
            thisCommand.CommandText = "update ManagerBookEntry set AvaliableBook = '" + textBox7.Text + "',QuantityOfBook = '" + textBox7.Text + "' where BookName = '" + textBox5.Text + "'";

            thisCommand.Connection = sv.thisConnection;
            thisCommand.CommandType = CommandType.Text;
            MessageBox.Show("Book Stock Updated");

            try
            {
                thisCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            sv.thisConnection.Close();
            this.Close();
            Manager_Edit_Book_Info ob = new Manager_Edit_Book_Info();
            ob.Show();
            this.Hide();
        }

        private void Manager_Edit_Book_Info_Load(object sender, EventArgs e)
        {
            comboBox3.Items.Add(new KeyValuePair<string, string>("BookName", "0"));
            comboBox3.Items.Add(new KeyValuePair<string, string>("WriterName", "1"));
            comboBox3.DisplayMember = "key";
            comboBox3.ValueMember = "value";
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                textBox1.Text = item.SubItems[0].Text;
                textBox6.Text = item.SubItems[1].Text;
                textBox2.Text = item.SubItems[2].Text;
                comboBox2.Text = item.SubItems[3].Text;
                dateTimePicker1.Text = item.SubItems[4].Text;
                textBox3.Text = item.SubItems[5].Text;
            }
            else
            {
                textBox1.Text = string.Empty;
                textBox6.Text = string.Empty;
                textBox2.Text = string.Empty;
                comboBox2.Text = string.Empty;
                textBox3.Text = string.Empty;
            }
        }
    }
}
